-ACK";
  sprintf(synack+7,"%4d",portData);
  socklen_t adrsize= sizeof(Client);


  recvfrom(descConnect,bufferConnect,RCVSIZE,0,Client,&adrsize);

  if (strcmp(bufferConnect,"SYN") ==0){
    printf("Réception synchronisation : %s\n", bufferConnect);
    memset(bufferConnect,0,RCVSIZE);
  }
  else{
    exit(1);
  }
  sendto(descConnect,synack,strlen(synack)+1,0,Client,adrsize);
  recvfrom(descConnect,bufferConnect,RCVSIZE,0, Client,&adrsize);

  if (strcmp(bufferConnect,"ACK") ==0){
    printf("Réception acquittement : %s\n", bufferConnect);
    memset(bufferConnect,0,RCVSIZE);

  }
  else{
    exit(1);
  }

}
//Fonction d'ouverture du fichier
FILE* openFich(int descData,struct sockaddr* Client,socklen_t adrsize){

  char bufferInit [RCVSIZE];
  recvfrom(descData,bufferInit,RCVSIZE,0,Client,&adrsize);
  char fichToOpen [RCVSIZE];
  strncpy(fichToOpen,bufferInit,RCVSIZE);

  //phase d'envoi avec acquittement
  FILE* fichier = NULL;
  fichier =fopen(fichToOpen,"rb");

  if(fichier!= NULL){
    printf("Ouverture du fichier avec succès\n");
  }
  else{
    printf("Erreur lors de l'ouverture du fichier\n");
  }
  return fichier;



}
//fonction envoi
void envoi(int descData, int numSeg,FILE* fichier, struct sockaddr* Client,socklen_t adrsize){

  //Envoi normal
  char bufferData [RCVSIZE+6];
  memset(bufferData,0,RCVSIZE+6);
  int sntSize=0;
  char message[RCVSIZE];
  memset(message,0,RCVSIZE);
  char StringSeg[6];
  memset(StringSeg,0,6);
  sprintf(StringSeg, "%06d",numSeg);
  memcpy(bufferData,StringSeg,6);
  //char ack [9]="ACK";
  //strncpy(ack+3,StringSeg,6);
  fseek(fichier,RCVSIZE*(numSeg),SEEK_SET);
  sntSize=fread(message,1,RCVSIZE,fichier);
  memcpy(bufferData+6,message,sntSize);
  sendto(descData,bufferData,sntSize+6,0,Client,adrsize);


  //Gestion de la fin du fichier
  if(sntSize==0){
    memset(bufferData,0,RCVSIZE+6);
    memcpy(bufferData,StringSeg,6);
    memcpy(bufferData+6,"FIN",3);
    sendto(descData,bufferData,9,0,Client,adrsize);
    printf("Fin du fichier\n");
    exit(1);
  }
}



int main (int argc, char *argv[]) {

  struct sockaddr_in Connect,Data,Client;
  char segPerdu [6];
  int descData,descConnect;
  int portData=8080;
  int portConnect;
  int numSeg=0;
  socklen_t adrsize=sizeof(Client);



  //Initialisation du port de connexion

  if(argc ==2){
    portConnect = atoi(argv[1]);
    printf("Le port de Connection est :%d\n",portConnect);
  }
  else {
    printf("Pas le bon nombre d'arguments en entrée\n");
    return 0;
  }

  initSocket(&descConnect,portConnect,Connect); 
  initConnexion(descConnect,portData,(struct sockaddr*) &Client);
  //printf("Data %d %d\n", ntohl(Data.sin_addr.s_addr), ntohs(Data.sin_port));
  initSocket(&descData, portData, Data);

  FILE* fichier=openFich(descData,(struct sockaddr*) &Client,adrsize);

  fd_set readset;
  struct timeval tv;
  tv.tv_sec = 2;  
  tv.tv_usec=0;
  int val=0;
  int segtmp=0;
  char bufferData[9];
  int i=0;

  while(1){

    FD_ZERO(&readset);
    FD_CLR(0, &readset);
    FD_SET(descData, &readset);

    //printf("Erreur avant select\n val:%d tv:%ld tv2:%ld\n ",val,tv.tv_sec,tv.tv_usec);
	envoi(descData,numSeg,fichier,(struct sockaddr*) &Client,adrsize);
	tv.tv_sec=2;
	tv.tv_usec=0;
    if(select(descData+1, &readset, NULL, NULL,&tv)<0){
      perror("select");
    }
    numSeg++;
    if (FD_ISSET(descData, &readset)) {
      printf("Erreur de récéption\n");
      //sleep(3);
      memset(segPerdu,0,6);
      memset(bufferData,0,9);
      recvfrom(descData,bufferData,9,0, (struct sockaddr*) &Client,&adrsize);
      memcpy(bufferData+3,segPerdu,6);
      if(segtmp==atoi(segPerdu)){
		  i++;
	  }
      if(i=2){
		  envoi(descData,atoi(segPerdu),fichier,(struct sockaddr*) &Client,adrsize);
      }
      else{
		i=1;
        segtmp=atoi(segPerdu);
      }
    }	        
    else{
      printf("Envoi\n");
 

      /* sth to snd */

    }
  }
}

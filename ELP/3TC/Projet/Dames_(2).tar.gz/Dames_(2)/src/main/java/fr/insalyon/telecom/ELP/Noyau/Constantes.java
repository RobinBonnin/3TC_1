package fr.insalyon.telecom.ELP.Noyau; 

/**
 * Classe regroupant les constantes
 */
public class Constantes {

    /** taille du cote du damier 
	(en nombre de cases */
    public static final int N = 10; 

}
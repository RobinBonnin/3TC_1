public abstract class FonctionDeRDansR {
	public abstract double evaluer(double x);
	
}

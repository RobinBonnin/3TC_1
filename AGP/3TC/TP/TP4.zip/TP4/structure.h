#include <stdio.h>
#include <stdlib.h>

typedef struct NODE {
 int instruction;
 int val;
 struct NODE* sousProgramme;
 struct NODE* instructionSuivant;
}NODE;



NODE* newNode (int inst,int Val, NODE* sousProg,NODE* instSuivant); // Création du noeud avec les instructions


NODE* addNode (NODE* noeudSource,NODE* programme);

void printProgram(NODE* programme);

static NODE* root;
	
	

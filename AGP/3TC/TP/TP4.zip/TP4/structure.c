#include <stdio.h>
#include "structure.h"
#include <stdlib.h>

#define FORWARD 1
#define REPEAT 2
#define LEFT 3
#define RIGHT 4




NODE* newNode (int inst,int Val, NODE* sousProg,NODE* instSuivant){
	NODE* cursor;
	cursor=(NODE*)malloc(sizeof(NODE));
	if(cursor==NULL)
		exit(-1);
		else{
	cursor->instruction=inst;
	cursor->val=Val;
	cursor-> sousProgramme=sousProg;
	cursor->instructionSuivant=instSuivant;
	}
return cursor;
}

NODE* addNode (NODE* noeudSource,NODE* programme){
	if(programme==NULL){
	fprintf(stderr,"Err : instruction vide\n");
		exit(-1);
	}		
	else if (noeudSource->instructionSuivant!=NULL){
			noeudSource->instructionSuivant=addNode(noeudSource->instructionSuivant,programme);
			}
			else {
			noeudSource->instructionSuivant=programme;
	}
return(noeudSource);		
}		

void printProgram(NODE* programme){
	if(programme==NULL){ 
		fprintf(stderr,"Err : Programme NULL\n");
		exit (0);
	}
	else{		
	switch(programme->instruction){
		case 1 :
		printf("\n");
		printf("FORWARD %d",programme->val);		
		break;
		case 2 :
		printf("\nREPEAT %d \n	[",programme->val);
		switch(programme->sousProgramme->instruction){
			case 1:
			printf("FORWARD %d" ,programme->sousProgramme->val);
			if(programme->sousProgramme->instructionSuivant!=NULL)
			printProgram(programme->sousProgramme->instructionSuivant);			
				printf( "]");
			break;
			case 2 :
			printf("REPEAT %d[\n		",programme->sousProgramme->val);
			printProgram(programme->sousProgramme->sousProgramme); 
			if(programme->sousProgramme->instructionSuivant!=NULL)
			printProgram(programme->sousProgramme->instructionSuivant);
			printf("]]");
			break;
			case 3 : 
			printf("LEFT %d",programme->sousProgramme->val);
			if(programme->sousProgramme->instructionSuivant!=NULL) 
			printProgram(programme->sousProgramme->instructionSuivant);
				printf( "]");
			break;
			case 4 :
			printf("RIGHT %d",programme->sousProgramme->val);
			if(programme->sousProgramme->instructionSuivant!=NULL)
			printProgram(programme->sousProgramme->instructionSuivant);
			printf("]");
			break;
		}
		printf("\n");			
		break;
		case 3 :
		printf("\n");
		printf("LEFT %d",programme->val);
		break;
		case 4 :
		printf("\n");
		printf("RIGHT %d",programme->val);		
		break;
		default :
		break;
	}
	}
	if(programme->instructionSuivant!=NULL){
		printProgram(programme->instructionSuivant);
	}
	else 
	printf("\n");
}
